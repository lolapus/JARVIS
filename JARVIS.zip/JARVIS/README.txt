Navigate to the Install/ChatterBot-master folder and follow the README.txt instructions.
Run the Main.py file to run JARVIS.

JARVIS can do:
--------------
math
tell time
tell the date
AI conversations
tell the temperature
tell the weather
search wikipedia
--------------