from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
import pyttsx3
from playsound import playsound
import os
import shutil
import sys
import Logic
import Adapter

if input("Run with the JARVIS voice? y or n: ") == "y":
    Voice = True
else:
    Voice = False

print("""

       _         _______      _______  _____ 
      | |  /\   |  __ \ \    / /_   _|/ ____|
      | | /  \  | |__) \ \  / /  | | | (___  
  _   | |/ /\ \ |  _  / \ \/ /   | |  \___ \ 
 | |__| / ____ \| | \ \  \  /   _| |_ ____) |
  \____/_/    \_\_|  \_\  \/   |_____|_____/ 
                                             


VER 1.0.4     LOADING.....
""")


shutil.copy("conversations.yml", sys.path[4]+"\\Lib\\site-packages\\chatterbot_corpus\\data\\english\\conversations.yml")

if Voice:
    engine = pyttsx3.init()
    engine.setProperty('rate', 125)


def Meaning(statement):
    result = Adapter.CheckMeaning(statement)
    if result:
        print("JARVIS: ", end='')
        print(result)
        if Voice:
            engine.say(result)
            engine.runAndWait()
        return True
    return False


def Conversation():
    chatbot = ChatBot('JARVIS')
    trainer = ChatterBotCorpusTrainer(chatbot)
    trainer.train("chatterbot.corpus.english.conversations")
    while True:
        words = input("You: ")
        if Meaning(words) == False:
            print("JARVIS: ", end='')
            response = chatbot.get_response(words)
            print(response)
            if Voice:
                engine.say(response)
                engine.runAndWait()


Conversation()
