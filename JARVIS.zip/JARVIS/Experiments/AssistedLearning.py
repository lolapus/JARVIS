from chatterbot import ChatBot
from chatterbot.conversation import Statement

bot = ChatBot(
    'JARVIS',
    storage_adapter='chatterbot.storage.SQLStorageAdapter'
)


def get_feedback():

    text = input()

    if 'yes' in text.lower():
        return True
    elif 'no' in text.lower():
        return False
    else:
        print('Please type either "Yes" or "No"')
        return get_feedback()


while True:
    try:
        input_statement = Statement(text=input("You: "))
        response = bot.generate_response(
            input_statement
        )

        print('\n Is "{}" a coherent response to "{}"? \n'.format(
            response.text,
            input_statement.text
        ))
        if get_feedback() is False:
            print('please input the correct one')
            correct_response = Statement(text=input())
            bot.learn_response(correct_response, input_statement)
            print('Response added to bot!')

    except (KeyboardInterrupt, EOFError, SystemExit):
        break
