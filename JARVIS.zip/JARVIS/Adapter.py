import Logic


def CheckMeaning(statement):
    TempWords = [['what', 'is', 'temperature'], ['whats', 'temperature'], ["what's", 'temperature'], ['what', 'is', 'temp'], ['whats', 'temp'], ["what's", 'temp']]
    if all(x in statement.split() for x in TempWords[0]) or all(x in statement.split() for x in TempWords[1]) or all(x in statement.split() for x in TempWords[2]) or all(x in statement.split() for x in TempWords[3]) or all(x in statement.split() for x in TempWords[4]) or all(x in statement.split() for x in TempWords[5]):
        return Logic.temperature(False)
    WethWords = [['what', 'is', 'weather'], ['whats', 'weather'], ["what's", 'weather']]
    if all(x in statement.split() for x in WethWords[0]) or all(x in statement.split() for x in WethWords[1]) or all(x in statement.split() for x in WethWords[2]):
        return Logic.temperature(True)
    TimeWords = [['what', 'is', 'time'], ['whats', 'time'], ["what's", 'time'], ["what", "time", "is", "it"]]
    if all(x in statement.split() for x in TimeWords[0]) or all(x in statement.split() for x in TimeWords[1]) or all(x in statement.split() for x in TimeWords[2]) or all(x in statement.split() for x in TimeWords[3]):
        return Logic.time(False)
    DateWords = [['what', 'is', 'date'], ['whats', 'date'], ["what's", 'date'], ["what", "day", "is", "it"], ["whats", "todays", "date"], ["what's", "todays", "date"]]
    if all(x in statement.split() for x in DateWords[0]) or all(x in statement.split() for x in DateWords[1]) or all(x in statement.split() for x in DateWords[2]) or all(x in statement.split() for x in DateWords[3]) or all(x in statement.split() for x in DateWords[4]) or all(x in statement.split() for x in DateWords[5]):
        return Logic.time(True)
    if Logic.math(statement):
        return Logic.math(statement)
    WikiWords = [['wikipedia', 'search'], ['wiki', 'search']]
    if all(x in statement.split() for x in WikiWords[0]) or all(x in statement.split() for x in WikiWords[1]):
        return Logic.wikipedia(statement)
    return False
