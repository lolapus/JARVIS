DO EVERYTHING IN ORDER!

Python and PIP must be under PATH for the install to work.
run "pip --version" to make sure everything is installed correctly.

Open cmd as and admin and navigate to this folder by using "pushd pathToThisFolder"

run "pip install PyAudio-0.2.11-cp38-cp38-win_amd64.whl" in an admin cmd
run "pip install -r requirements.txt" in an admin cmd
run "pip install -r dev-requirements.txt" in an admin cmd
run "python -m spacy download en" in an admin cmd
run "setup.py build" in an admin cmd
run "setup.py install" in an admin cmd