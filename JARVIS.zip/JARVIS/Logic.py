def temperature(weather):
    import requests, json
    api_key = "32f9f174af09a86c8f3213b41cc15984"
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    city_name = "Spicewood"
    complete_url = base_url + "q=" + city_name + "&appid=" + api_key
    try:
        response = requests.get(complete_url)
    except:
        return "I was unable to retrieve the data"
    x = response.json()
    if x["cod"] != "404":
        y = x["main"]
        temperature = y["temp"]
        pressure = y["pressure"]
        humidiy = y["humidity"]
        z = x["weather"]
        weather_description = z[0]["description"]
        if weather:
            return '{}'.format(weather_description)
        else:
            return 'The current temperature is {}° Fahrenheit'.format(str(int((int(temperature)*(9/5))-459.67)))
    else:
        return "I was unable to retrieve the data"


def time(dateBool):
    from datetime import date
    import time
    if dateBool:
        today = date.today()
        return today.strftime("%B %d, %Y")
    else:
        t = time.localtime()
        return time.strftime("%H:%M", t)


def math(statement):
    from chatterbot import languages
    from mathparse import mathparse
    expression = mathparse.extract_expression(statement, language=languages.ENG.ISO_639.upper())
    response = expression
    try:
        response += ' = ' + str(
            mathparse.parse(expression, language=languages.ENG.ISO_639.upper())
        )
        return response
    except mathparse.PostfixTokenEvaluationException:
        return False

def wikipedia(text):
    import wikipedia
    try:
        if "wikipedia" in text:
            statement = text.replace('wikipedia search ', '')
        elif "wiki" in text:
            statement = text.replace('wiki search ', '')
        data = wikipedia.summary(statement, sentences=3)
        return data
    except Exception as ex:
        return ex
